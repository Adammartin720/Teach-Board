﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects


namespace Teach_Boards
{
    
    public partial class frmstudentques : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        DataSet ds2;
        String sql;
        OleDbDataAdapter da, da2;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;
        int StudentID;
        int SessionID;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmstudentques()
        {
            InitializeComponent();
        }

        private void frmstudentques_Load(object sender, EventArgs e)
        {
            
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();


                sql = "SELECT Questions.QuestionID, Questions.Question, Questions.A, Questions.B, Questions.C, Questions.D, Questions.Correct, Questions.Media FROM Questions ORDER BY Questions.QuestionID; ";
                
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "Questions");
                numRows = ds.Tables["Questions"].Rows.Count;
                populateQuestions();

                
                ds2 = new DataSet();

                sql = "SELECT * FROM StudentAnswers";
                da2 = new OleDbDataAdapter(sql, con);
                da2.Fill(ds2, "StudentAnswers");
              // numRows = ds2.Tables["StudentAnswers"].Rows.Count;

            
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void populateQuestions()
        {
            dRow = ds.Tables["Questions"].Rows[currentRow];
            String questionid = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = questionid;
            trackID = questionid;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;

            String answera = dRow.ItemArray.GetValue(2).ToString();
            lblanswera.Text = answera;

            String answerb = dRow.ItemArray.GetValue(3).ToString();
            lblanswerb.Text = answerb;

            String answerc = dRow.ItemArray.GetValue(4).ToString();
            lblanswerc.Text = answerc;

            String answerd = dRow.ItemArray.GetValue(5).ToString();
            lblanswerd.Text = answerd;

            String Media = dRow.ItemArray.GetValue(7).ToString();
            lblvideo.Text = Media;
        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
                System.Diagnostics.Process.Start(lblvideo.Text);
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            
            StudentID = Int32.Parse(txtstudid.Text);
            SessionID = Int32.Parse(txtsessionid.Text);

            txtsessionid.Hide();
            txtstudid.Hide();
            btnlogin.Hide();
        }

        private void btnupload_Click(object sender, EventArgs e)
        {

            if (rbanswer1.Checked == true) { answermc(lblquestionid.Text, rbanswer1.Text); }
            if (rbanswer2.Checked == true) { answermc(lblquestionid.Text, rbanswer2.Text); }
            if (rbanswer3.Checked == true) { answermc(lblquestionid.Text, rbanswer3.Text); }
            if (rbanswer4.Checked == true) { answermc(lblquestionid.Text, rbanswer4.Text); }

            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateQuestions();
            }
        }


        private void answermc(string QID,string answ)
        {
            try
            {
                DataRow dRow = ds2.Tables["StudentAnswers"].NewRow();
                dRow[1] = StudentID;
                dRow[2] = QID;
                dRow[3] = answ;
                dRow[4] = SessionID;
                ds2.Tables["StudentAnswers"].Rows.Add(dRow);
                //numRows = numRows + 1;
                // currentRow = numRows - 1;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da2);
                cb.DataAdapter.Update(ds2.Tables["StudentAnswers"]);

                MessageBox.Show("Question Uploaded");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }


    }
}
