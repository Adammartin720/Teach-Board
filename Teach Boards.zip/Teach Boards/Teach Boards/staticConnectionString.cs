﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teach_Boards
{
    class staticConnectionString
    {
        static public string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Assignment Database.accdb";
    }
}
