﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmteach : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        String sql;
        OleDbDataAdapter da;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmteach()
        {
            InitializeComponent();
        }

        private void frmteach_Load(object sender, EventArgs e)
        {
            
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();
                sql = "SELECT * FROM Questions";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "Questions");
                numRows = ds.Tables["Questions"].Rows.Count;
                populateQuestions();
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void populateQuestions()
        {
            dRow = ds.Tables["Questions"].Rows[currentRow];
            String questionid = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = questionid;
            trackID = questionid;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;

            String answera = dRow.ItemArray.GetValue(2).ToString();
            lblanswera.Text = answera;

            String answerb = dRow.ItemArray.GetValue(3).ToString();
            lblanswerb.Text = answerb;

            String answerc = dRow.ItemArray.GetValue(4).ToString();
            lblanswerc.Text = answerc;

            String answerd = dRow.ItemArray.GetValue(5).ToString();
            lblanswerd.Text = answerd;

            String Media = dRow.ItemArray.GetValue(7).ToString();
            lblvideo.Text = Media;
        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(lblvideo.Text);
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateQuestions();
            }
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            if (currentRow > 0)
            {
                currentRow--;
                populateQuestions();
            }
        }

        private void btnstudans_Click(object sender, EventArgs e)
        {
            frmviewstudanswermc fm = new frmviewstudanswermc();
            fm.ShowDialog();
        }
    }
}
