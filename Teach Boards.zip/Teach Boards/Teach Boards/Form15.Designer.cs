﻿namespace Teach_Boards
{
    partial class frmteachmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmteachmenu));
            this.btnessay = new System.Windows.Forms.Button();
            this.btnpicture = new System.Windows.Forms.Button();
            this.btnmc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnessaycreate = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnessay
            // 
            this.btnessay.BackColor = System.Drawing.Color.White;
            this.btnessay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnessay.Location = new System.Drawing.Point(18, 173);
            this.btnessay.Name = "btnessay";
            this.btnessay.Size = new System.Drawing.Size(100, 50);
            this.btnessay.TabIndex = 25;
            this.btnessay.Text = "Essay Quest";
            this.btnessay.UseVisualStyleBackColor = false;
            this.btnessay.Click += new System.EventHandler(this.btnessay_Click);
            // 
            // btnpicture
            // 
            this.btnpicture.BackColor = System.Drawing.Color.White;
            this.btnpicture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpicture.Location = new System.Drawing.Point(18, 117);
            this.btnpicture.Name = "btnpicture";
            this.btnpicture.Size = new System.Drawing.Size(100, 50);
            this.btnpicture.TabIndex = 24;
            this.btnpicture.Text = "Picture Quest";
            this.btnpicture.UseVisualStyleBackColor = false;
            this.btnpicture.Click += new System.EventHandler(this.btnpicture_Click);
            // 
            // btnmc
            // 
            this.btnmc.BackColor = System.Drawing.Color.White;
            this.btnmc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmc.Location = new System.Drawing.Point(18, 61);
            this.btnmc.Name = "btnmc";
            this.btnmc.Size = new System.Drawing.Size(100, 50);
            this.btnmc.TabIndex = 23;
            this.btnmc.Text = "Multiple Choice";
            this.btnmc.UseVisualStyleBackColor = false;
            this.btnmc.Click += new System.EventHandler(this.btnmc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "Teacher Menu";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(135, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 50);
            this.button1.TabIndex = 26;
            this.button1.Text = "MC Creation";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(135, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 50);
            this.button2.TabIndex = 27;
            this.button2.Text = "Picture Creation";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnessaycreate
            // 
            this.btnessaycreate.BackColor = System.Drawing.Color.White;
            this.btnessaycreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnessaycreate.Location = new System.Drawing.Point(135, 173);
            this.btnessaycreate.Name = "btnessaycreate";
            this.btnessaycreate.Size = new System.Drawing.Size(100, 50);
            this.btnessaycreate.TabIndex = 29;
            this.btnessaycreate.Text = "Essay Creation";
            this.btnessaycreate.UseVisualStyleBackColor = false;
            this.btnessaycreate.Click += new System.EventHandler(this.btnessaycreate_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(254, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // frmteachmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(426, 232);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnessaycreate);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnessay);
            this.Controls.Add(this.btnpicture);
            this.Controls.Add(this.btnmc);
            this.Controls.Add(this.label1);
            this.Name = "frmteachmenu";
            this.Text = "Teacher Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnessay;
        private System.Windows.Forms.Button btnpicture;
        private System.Windows.Forms.Button btnmc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnessaycreate;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}