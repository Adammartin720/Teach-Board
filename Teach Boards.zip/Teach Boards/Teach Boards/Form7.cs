﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class Form7 : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        String sql;
        OleDbDataAdapter da;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();


                sql = "SELECT * FROM Questions";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "Questions");
                numRows = ds.Tables["Questions"].Rows.Count;
                populatequestionmccreate();


            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void populatequestionmccreate()
        {
            dRow = ds.Tables["Questions"].Rows[currentRow];
            String ImageQuestID = dRow.ItemArray.GetValue(0).ToString();
            txtID.Text = ImageQuestID;
            trackID = ImageQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquesname.Text = question;

            String answera = dRow.ItemArray.GetValue(2).ToString();
            txtanswera.Text = answera;

            String answerb = dRow.ItemArray.GetValue(3).ToString();
            txtanswerb.Text = answerb;

            String answerc = dRow.ItemArray.GetValue(4).ToString();
            txtanswerc.Text = answerc;

            String answerd = dRow.ItemArray.GetValue(5).ToString();
            txtanswerd.Text = answerd;

            String correct = dRow.ItemArray.GetValue(6).ToString();
            txtanswer.Text = correct;

            String Media = dRow.ItemArray.GetValue(7).ToString();
            txtmedia.Text = Media;
                       
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dRow = ds.Tables["Questions"].NewRow();
                dRow[1] = txtquesname.Text;
                dRow[2] = txtanswera.Text;
                dRow[3] = txtanswerb.Text;
                dRow[4] = txtanswerc.Text;
                dRow[5] = txtanswerd.Text;
                dRow[6] = txtanswer.Text;
                dRow[7] = txtmedia.Text;

                ds.Tables["Questions"].Rows.Add(dRow);
                numRows = numRows + 1;
                currentRow = numRows - 1;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["Questions"]);
                btnSave.Enabled = false;
                btnNew.Enabled = true;
                MessageBox.Show("Record saved");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentRow < numRows - 1)
            {
                currentRow++;
                populatequestionmccreate();
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentRow > 0)
            {
                currentRow--;
                populatequestionmccreate();
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentRow = 0;
            populatequestionmccreate();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentRow = numRows - 1;
            populatequestionmccreate();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtquesname.Clear();
            txtID.Clear();
            txtanswera.Clear();
            txtanswerb.Clear();
            txtanswerc.Clear();
            txtanswerd.Clear();
            txtanswer.Clear();
            txtmedia.Clear();

            btnSave.Enabled = true;
            btnNew.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnNext.Enabled = false;
            btnPrevious.Enabled = false;
            btnFirst.Enabled = false;
            btnLast.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dRow2 = ds.Tables["Questions"].Rows[currentRow];
                dRow2[1] = txtquesname.Text;
                dRow2[2] = txtanswera.Text;
                dRow2[3] = txtanswerb.Text;
                dRow2[4] = txtanswerc.Text;
                dRow2[5] = txtanswerd.Text;
                dRow2[6] = txtanswer.Text;
                dRow2[7] = txtmedia.Text;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["Questions"]);

                MessageBox.Show("Questions updated");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Tables["Questions"].Rows[currentRow].Delete();
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["Questions"]);
                numRows = ds.Tables["Questions"].Rows.Count;
                MessageBox.Show("Questions record deleted");
                currentRow = currentRow - 1;
                populatequestionmccreate();
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
