﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teach_Boards
{
    public partial class frmteachmenu : Form
    {
        public frmteachmenu()
        {
            InitializeComponent();
        }

        private void btnmc_Click(object sender, EventArgs e)
        {
            frmteach fm = new frmteach();
            fm.ShowDialog();
        }

        private void btnpicture_Click(object sender, EventArgs e)
        {
            frmteachboard2 fm = new frmteachboard2();
            fm.ShowDialog();
        }

        private void btnessaycreate_Click(object sender, EventArgs e)
        {
            frmessaycreate fm = new frmessaycreate();
            fm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 fm = new Form7();
            fm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmquestioncreate fm = new frmquestioncreate();
            fm.ShowDialog();
        }

        private void btnessay_Click(object sender, EventArgs e)
        {
            frmessayboard fm = new frmessayboard();
            fm.ShowDialog();
        }
    }
}
