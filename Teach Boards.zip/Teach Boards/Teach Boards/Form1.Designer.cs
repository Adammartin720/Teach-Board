﻿namespace Teach_Boards
{
    partial class frmteach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmedia = new System.Windows.Forms.Button();
            this.lblanswera = new System.Windows.Forms.Label();
            this.lblanswerb = new System.Windows.Forms.Label();
            this.lblanswerc = new System.Windows.Forms.Label();
            this.lblanswerd = new System.Windows.Forms.Label();
            this.txtquestion = new System.Windows.Forms.TextBox();
            this.lblquestionid = new System.Windows.Forms.Label();
            this.lblvideo = new System.Windows.Forms.Label();
            this.btnprev = new System.Windows.Forms.Button();
            this.btnnext = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnstudans = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnmedia
            // 
            this.btnmedia.BackColor = System.Drawing.Color.White;
            this.btnmedia.Location = new System.Drawing.Point(146, 203);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(68, 37);
            this.btnmedia.TabIndex = 0;
            this.btnmedia.Text = "Media";
            this.btnmedia.UseVisualStyleBackColor = false;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // lblanswera
            // 
            this.lblanswera.AutoSize = true;
            this.lblanswera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswera.Location = new System.Drawing.Point(260, 18);
            this.lblanswera.Name = "lblanswera";
            this.lblanswera.Size = new System.Drawing.Size(18, 18);
            this.lblanswera.TabIndex = 1;
            this.lblanswera.Text = "A";
            // 
            // lblanswerb
            // 
            this.lblanswerb.AutoSize = true;
            this.lblanswerb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswerb.Location = new System.Drawing.Point(261, 76);
            this.lblanswerb.Name = "lblanswerb";
            this.lblanswerb.Size = new System.Drawing.Size(19, 18);
            this.lblanswerb.TabIndex = 2;
            this.lblanswerb.Text = "B";
            // 
            // lblanswerc
            // 
            this.lblanswerc.AutoSize = true;
            this.lblanswerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswerc.Location = new System.Drawing.Point(261, 140);
            this.lblanswerc.Name = "lblanswerc";
            this.lblanswerc.Size = new System.Drawing.Size(20, 18);
            this.lblanswerc.TabIndex = 3;
            this.lblanswerc.Text = "C";
            // 
            // lblanswerd
            // 
            this.lblanswerd.AutoSize = true;
            this.lblanswerd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswerd.Location = new System.Drawing.Point(261, 203);
            this.lblanswerd.Name = "lblanswerd";
            this.lblanswerd.Size = new System.Drawing.Size(20, 18);
            this.lblanswerd.TabIndex = 4;
            this.lblanswerd.Text = "D";
            // 
            // txtquestion
            // 
            this.txtquestion.BackColor = System.Drawing.Color.White;
            this.txtquestion.Location = new System.Drawing.Point(21, 69);
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.ReadOnly = true;
            this.txtquestion.Size = new System.Drawing.Size(147, 20);
            this.txtquestion.TabIndex = 5;
            // 
            // lblquestionid
            // 
            this.lblquestionid.AutoSize = true;
            this.lblquestionid.Location = new System.Drawing.Point(55, 49);
            this.lblquestionid.Name = "lblquestionid";
            this.lblquestionid.Size = new System.Drawing.Size(60, 13);
            this.lblquestionid.TabIndex = 6;
            this.lblquestionid.Text = "QuestionID";
            // 
            // lblvideo
            // 
            this.lblvideo.AutoSize = true;
            this.lblvideo.Location = new System.Drawing.Point(162, 187);
            this.lblvideo.Name = "lblvideo";
            this.lblvideo.Size = new System.Drawing.Size(36, 13);
            this.lblvideo.TabIndex = 7;
            this.lblvideo.Text = "Media";
            this.lblvideo.Visible = false;
            // 
            // btnprev
            // 
            this.btnprev.BackColor = System.Drawing.Color.White;
            this.btnprev.Location = new System.Drawing.Point(43, 101);
            this.btnprev.Name = "btnprev";
            this.btnprev.Size = new System.Drawing.Size(46, 31);
            this.btnprev.TabIndex = 8;
            this.btnprev.Text = "Prev";
            this.btnprev.UseVisualStyleBackColor = false;
            this.btnprev.Click += new System.EventHandler(this.btnprev_Click);
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.White;
            this.btnnext.Location = new System.Drawing.Point(95, 101);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(46, 31);
            this.btnnext.TabIndex = 9;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = false;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Multiple Choice Board";
            // 
            // btnstudans
            // 
            this.btnstudans.BackColor = System.Drawing.Color.White;
            this.btnstudans.ForeColor = System.Drawing.Color.Black;
            this.btnstudans.Location = new System.Drawing.Point(16, 203);
            this.btnstudans.Name = "btnstudans";
            this.btnstudans.Size = new System.Drawing.Size(112, 37);
            this.btnstudans.TabIndex = 11;
            this.btnstudans.Text = "View Student Results";
            this.btnstudans.UseVisualStyleBackColor = false;
            this.btnstudans.Click += new System.EventHandler(this.btnstudans_Click);
            // 
            // frmteach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(402, 250);
            this.Controls.Add(this.btnstudans);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.btnprev);
            this.Controls.Add(this.lblvideo);
            this.Controls.Add(this.lblquestionid);
            this.Controls.Add(this.txtquestion);
            this.Controls.Add(this.lblanswerd);
            this.Controls.Add(this.lblanswerc);
            this.Controls.Add(this.lblanswerb);
            this.Controls.Add(this.lblanswera);
            this.Controls.Add(this.btnmedia);
            this.Name = "frmteach";
            this.Text = "teachboard1";
            this.Load += new System.EventHandler(this.frmteach_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Label lblanswera;
        private System.Windows.Forms.Label lblanswerb;
        private System.Windows.Forms.Label lblanswerc;
        private System.Windows.Forms.Label lblanswerd;
        private System.Windows.Forms.TextBox txtquestion;
        private System.Windows.Forms.Label lblquestionid;
        private System.Windows.Forms.Label lblvideo;
        private System.Windows.Forms.Button btnprev;
        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnstudans;
    }
}

