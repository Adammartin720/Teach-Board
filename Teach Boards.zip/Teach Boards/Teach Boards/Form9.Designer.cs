﻿namespace Teach_Boards
{
    partial class frmstudmenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmstudmenu));
            this.label1 = new System.Windows.Forms.Label();
            this.btnmc = new System.Windows.Forms.Button();
            this.btnpicture = new System.Windows.Forms.Button();
            this.btnessay = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 25);
            this.label1.TabIndex = 18;
            this.label1.Text = "Student Menu";
            // 
            // btnmc
            // 
            this.btnmc.BackColor = System.Drawing.Color.White;
            this.btnmc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmc.Location = new System.Drawing.Point(35, 59);
            this.btnmc.Name = "btnmc";
            this.btnmc.Size = new System.Drawing.Size(100, 50);
            this.btnmc.TabIndex = 19;
            this.btnmc.Text = "Multiple Choice";
            this.btnmc.UseVisualStyleBackColor = false;
            this.btnmc.Click += new System.EventHandler(this.btnmc_Click);
            // 
            // btnpicture
            // 
            this.btnpicture.BackColor = System.Drawing.Color.White;
            this.btnpicture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpicture.Location = new System.Drawing.Point(35, 115);
            this.btnpicture.Name = "btnpicture";
            this.btnpicture.Size = new System.Drawing.Size(100, 50);
            this.btnpicture.TabIndex = 20;
            this.btnpicture.Text = "Picture Quest";
            this.btnpicture.UseVisualStyleBackColor = false;
            this.btnpicture.Click += new System.EventHandler(this.btnpicture_Click);
            // 
            // btnessay
            // 
            this.btnessay.BackColor = System.Drawing.Color.White;
            this.btnessay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnessay.Location = new System.Drawing.Point(35, 171);
            this.btnessay.Name = "btnessay";
            this.btnessay.Size = new System.Drawing.Size(100, 50);
            this.btnessay.TabIndex = 21;
            this.btnessay.Text = "Essay Quest";
            this.btnessay.UseVisualStyleBackColor = false;
            this.btnessay.Click += new System.EventHandler(this.btnessay_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(161, 84);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // frmstudmenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(350, 235);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnessay);
            this.Controls.Add(this.btnpicture);
            this.Controls.Add(this.btnmc);
            this.Controls.Add(this.label1);
            this.Name = "frmstudmenu";
            this.Text = "Form9";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnmc;
        private System.Windows.Forms.Button btnpicture;
        private System.Windows.Forms.Button btnessay;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}