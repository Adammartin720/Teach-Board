﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teach_Boards
{
    public partial class frmstudmenu : Form
    {
        public frmstudmenu()
        {
            InitializeComponent();
        }

        private void btnmc_Click(object sender, EventArgs e)
        {
            frmstudentques fm = new frmstudentques();
            fm.ShowDialog();
        }

        private void btnpicture_Click(object sender, EventArgs e)
        {
            frmpicquestion fm = new frmpicquestion();
            fm.ShowDialog();
        }

        private void btnessay_Click(object sender, EventArgs e)
        {

            frmesasayques fm = new frmesasayques();
            fm.ShowDialog();
        }
    }
}
