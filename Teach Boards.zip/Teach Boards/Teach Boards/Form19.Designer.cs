﻿namespace Teach_Boards
{
    partial class frmessayboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmessayboard));
            this.label2 = new System.Windows.Forms.Label();
            this.picquestion = new System.Windows.Forms.PictureBox();
            this.btnstudans = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnnext = new System.Windows.Forms.Button();
            this.btnprev = new System.Windows.Forms.Button();
            this.lblquestionid = new System.Windows.Forms.Label();
            this.txtquestion = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picquestion)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 48);
            this.label2.TabIndex = 33;
            this.label2.Text = "Write Your thoughts\r\nAnd Feelings";
            // 
            // picquestion
            // 
            this.picquestion.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picquestion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picquestion.Image = ((System.Drawing.Image)(resources.GetObject("picquestion.Image")));
            this.picquestion.Location = new System.Drawing.Point(232, 36);
            this.picquestion.Name = "picquestion";
            this.picquestion.Size = new System.Drawing.Size(158, 183);
            this.picquestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picquestion.TabIndex = 32;
            this.picquestion.TabStop = false;
            // 
            // btnstudans
            // 
            this.btnstudans.BackColor = System.Drawing.Color.White;
            this.btnstudans.ForeColor = System.Drawing.Color.Black;
            this.btnstudans.Location = new System.Drawing.Point(16, 204);
            this.btnstudans.Name = "btnstudans";
            this.btnstudans.Size = new System.Drawing.Size(112, 37);
            this.btnstudans.TabIndex = 31;
            this.btnstudans.Text = "View Student Results";
            this.btnstudans.UseVisualStyleBackColor = false;
            this.btnstudans.Click += new System.EventHandler(this.btnstudans_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 24);
            this.label1.TabIndex = 30;
            this.label1.Text = "Essay Description Board";
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.White;
            this.btnnext.Location = new System.Drawing.Point(95, 101);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(46, 31);
            this.btnnext.TabIndex = 29;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = false;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // btnprev
            // 
            this.btnprev.BackColor = System.Drawing.Color.White;
            this.btnprev.Location = new System.Drawing.Point(43, 101);
            this.btnprev.Name = "btnprev";
            this.btnprev.Size = new System.Drawing.Size(46, 31);
            this.btnprev.TabIndex = 28;
            this.btnprev.Text = "Prev";
            this.btnprev.UseVisualStyleBackColor = false;
            this.btnprev.Click += new System.EventHandler(this.btnprev_Click);
            // 
            // lblquestionid
            // 
            this.lblquestionid.AutoSize = true;
            this.lblquestionid.Location = new System.Drawing.Point(55, 49);
            this.lblquestionid.Name = "lblquestionid";
            this.lblquestionid.Size = new System.Drawing.Size(60, 13);
            this.lblquestionid.TabIndex = 27;
            this.lblquestionid.Text = "QuestionID";
            // 
            // txtquestion
            // 
            this.txtquestion.BackColor = System.Drawing.Color.White;
            this.txtquestion.Location = new System.Drawing.Point(21, 69);
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.ReadOnly = true;
            this.txtquestion.Size = new System.Drawing.Size(147, 20);
            this.txtquestion.TabIndex = 26;
            // 
            // frmessayboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(405, 251);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picquestion);
            this.Controls.Add(this.btnstudans);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.btnprev);
            this.Controls.Add(this.lblquestionid);
            this.Controls.Add(this.txtquestion);
            this.Name = "frmessayboard";
            this.Text = "Form19";
            this.Load += new System.EventHandler(this.frmessayboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picquestion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picquestion;
        private System.Windows.Forms.Button btnstudans;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.Button btnprev;
        private System.Windows.Forms.Label lblquestionid;
        private System.Windows.Forms.TextBox txtquestion;
    }
}