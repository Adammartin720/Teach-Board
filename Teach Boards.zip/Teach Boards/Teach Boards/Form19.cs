﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmessayboard : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        String sql;
        OleDbDataAdapter da;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmessayboard()
        {
            InitializeComponent();
        }

        private void frmessayboard_Load(object sender, EventArgs e)
        {
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();
                sql = "SELECT * FROM EssayQuest";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "EssayQuest");
                numRows = ds.Tables["EssayQuest"].Rows.Count;
                populateEssayQuest();
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void populateEssayQuest()
        {
            dRow = ds.Tables["EssayQuest"].Rows[currentRow];
            String EssayQuestID = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = EssayQuestID;
            trackID = EssayQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;

            }

        private void btnnext_Click(object sender, EventArgs e)
        {
            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateEssayQuest();
            }
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            if (currentRow > 0)
            {
                currentRow--;
                populateEssayQuest();
            }
        }

        private void btnstudans_Click(object sender, EventArgs e)
        {
            frmessayview fm = new frmessayview();
            fm.ShowDialog();
        }
    }
}
