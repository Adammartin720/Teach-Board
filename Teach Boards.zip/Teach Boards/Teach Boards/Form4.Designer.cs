﻿namespace Teach_Boards
{
    partial class frmesasayques
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmesasayques));
            this.lblquestionid = new System.Windows.Forms.Label();
            this.btnupload = new System.Windows.Forms.Button();
            this.txtquestion = new System.Windows.Forms.TextBox();
            this.txtans = new System.Windows.Forms.RichTextBox();
            this.btnlogin = new System.Windows.Forms.Button();
            this.txtsessionid = new System.Windows.Forms.TextBox();
            this.txtstudid = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblquestionid
            // 
            this.lblquestionid.AutoSize = true;
            this.lblquestionid.Location = new System.Drawing.Point(100, 94);
            this.lblquestionid.Name = "lblquestionid";
            this.lblquestionid.Size = new System.Drawing.Size(35, 13);
            this.lblquestionid.TabIndex = 25;
            this.lblquestionid.Text = "label1";
            // 
            // btnupload
            // 
            this.btnupload.BackColor = System.Drawing.Color.White;
            this.btnupload.Location = new System.Drawing.Point(26, 330);
            this.btnupload.Name = "btnupload";
            this.btnupload.Size = new System.Drawing.Size(67, 34);
            this.btnupload.TabIndex = 24;
            this.btnupload.Text = "Upload";
            this.btnupload.UseVisualStyleBackColor = false;
            this.btnupload.Click += new System.EventHandler(this.btnupload_Click);
            // 
            // txtquestion
            // 
            this.txtquestion.Location = new System.Drawing.Point(44, 110);
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.ReadOnly = true;
            this.txtquestion.Size = new System.Drawing.Size(147, 20);
            this.txtquestion.TabIndex = 22;
            // 
            // txtans
            // 
            this.txtans.Location = new System.Drawing.Point(32, 167);
            this.txtans.Name = "txtans";
            this.txtans.Size = new System.Drawing.Size(165, 144);
            this.txtans.TabIndex = 26;
            this.txtans.Text = "";
            // 
            // btnlogin
            // 
            this.btnlogin.BackColor = System.Drawing.Color.White;
            this.btnlogin.Location = new System.Drawing.Point(80, 164);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnlogin.Size = new System.Drawing.Size(75, 23);
            this.btnlogin.TabIndex = 41;
            this.btnlogin.Text = "Login";
            this.btnlogin.UseVisualStyleBackColor = false;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // txtsessionid
            // 
            this.txtsessionid.Location = new System.Drawing.Point(134, 141);
            this.txtsessionid.Name = "txtsessionid";
            this.txtsessionid.Size = new System.Drawing.Size(57, 20);
            this.txtsessionid.TabIndex = 40;
            // 
            // txtstudid
            // 
            this.txtstudid.Location = new System.Drawing.Point(44, 141);
            this.txtstudid.Name = "txtstudid";
            this.txtstudid.Size = new System.Drawing.Size(57, 20);
            this.txtstudid.TabIndex = 39;
            // 
            // frmesasayques
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(229, 458);
            this.Controls.Add(this.btnlogin);
            this.Controls.Add(this.txtsessionid);
            this.Controls.Add(this.txtstudid);
            this.Controls.Add(this.txtans);
            this.Controls.Add(this.lblquestionid);
            this.Controls.Add(this.btnupload);
            this.Controls.Add(this.txtquestion);
            this.DoubleBuffered = true;
            this.Name = "frmesasayques";
            this.Text = "EssayQuestion";
            this.Load += new System.EventHandler(this.frmesasayques_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblquestionid;
        private System.Windows.Forms.Button btnupload;
        private System.Windows.Forms.TextBox txtquestion;
        private System.Windows.Forms.RichTextBox txtans;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.TextBox txtsessionid;
        private System.Windows.Forms.TextBox txtstudid;
    }
}