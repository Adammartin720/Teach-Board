﻿namespace Teach_Boards
{
    partial class frmpicquestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmpicquestion));
            this.lblquestionid = new System.Windows.Forms.Label();
            this.btnupload = new System.Windows.Forms.Button();
            this.txtquestion = new System.Windows.Forms.TextBox();
            this.picquestion = new System.Windows.Forms.PictureBox();
            this.rdbtrue = new System.Windows.Forms.RadioButton();
            this.rdbfalse = new System.Windows.Forms.RadioButton();
            this.btnlogin = new System.Windows.Forms.Button();
            this.txtsessionid = new System.Windows.Forms.TextBox();
            this.txtstudid = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picquestion)).BeginInit();
            this.SuspendLayout();
            // 
            // lblquestionid
            // 
            this.lblquestionid.AutoSize = true;
            this.lblquestionid.Location = new System.Drawing.Point(103, 90);
            this.lblquestionid.Name = "lblquestionid";
            this.lblquestionid.Size = new System.Drawing.Size(35, 13);
            this.lblquestionid.TabIndex = 31;
            this.lblquestionid.Text = "label1";
            // 
            // btnupload
            // 
            this.btnupload.BackColor = System.Drawing.Color.White;
            this.btnupload.Location = new System.Drawing.Point(29, 326);
            this.btnupload.Name = "btnupload";
            this.btnupload.Size = new System.Drawing.Size(67, 34);
            this.btnupload.TabIndex = 30;
            this.btnupload.Text = "Upload";
            this.btnupload.UseVisualStyleBackColor = false;
            this.btnupload.Click += new System.EventHandler(this.btnupload_Click);
            // 
            // txtquestion
            // 
            this.txtquestion.BackColor = System.Drawing.Color.White;
            this.txtquestion.Location = new System.Drawing.Point(47, 106);
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.ReadOnly = true;
            this.txtquestion.Size = new System.Drawing.Size(147, 20);
            this.txtquestion.TabIndex = 28;
            // 
            // picquestion
            // 
            this.picquestion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picquestion.Location = new System.Drawing.Point(29, 158);
            this.picquestion.Name = "picquestion";
            this.picquestion.Size = new System.Drawing.Size(177, 139);
            this.picquestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picquestion.TabIndex = 32;
            this.picquestion.TabStop = false;
            // 
            // rdbtrue
            // 
            this.rdbtrue.AutoSize = true;
            this.rdbtrue.Location = new System.Drawing.Point(51, 303);
            this.rdbtrue.Name = "rdbtrue";
            this.rdbtrue.Size = new System.Drawing.Size(47, 17);
            this.rdbtrue.TabIndex = 33;
            this.rdbtrue.TabStop = true;
            this.rdbtrue.Text = "True";
            this.rdbtrue.UseVisualStyleBackColor = true;
            // 
            // rdbfalse
            // 
            this.rdbfalse.AutoSize = true;
            this.rdbfalse.Location = new System.Drawing.Point(139, 303);
            this.rdbfalse.Name = "rdbfalse";
            this.rdbfalse.Size = new System.Drawing.Size(50, 17);
            this.rdbfalse.TabIndex = 34;
            this.rdbfalse.TabStop = true;
            this.rdbfalse.Text = "False";
            this.rdbfalse.UseVisualStyleBackColor = true;
            // 
            // btnlogin
            // 
            this.btnlogin.BackColor = System.Drawing.Color.White;
            this.btnlogin.Location = new System.Drawing.Point(83, 158);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnlogin.Size = new System.Drawing.Size(75, 23);
            this.btnlogin.TabIndex = 37;
            this.btnlogin.Text = "Login";
            this.btnlogin.UseVisualStyleBackColor = false;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // txtsessionid
            // 
            this.txtsessionid.Location = new System.Drawing.Point(137, 132);
            this.txtsessionid.Name = "txtsessionid";
            this.txtsessionid.Size = new System.Drawing.Size(57, 20);
            this.txtsessionid.TabIndex = 36;
            // 
            // txtstudid
            // 
            this.txtstudid.Location = new System.Drawing.Point(47, 132);
            this.txtstudid.Name = "txtstudid";
            this.txtstudid.Size = new System.Drawing.Size(57, 20);
            this.txtstudid.TabIndex = 35;
            // 
            // frmpicquestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(236, 456);
            this.Controls.Add(this.btnlogin);
            this.Controls.Add(this.txtsessionid);
            this.Controls.Add(this.txtstudid);
            this.Controls.Add(this.rdbfalse);
            this.Controls.Add(this.rdbtrue);
            this.Controls.Add(this.picquestion);
            this.Controls.Add(this.lblquestionid);
            this.Controls.Add(this.btnupload);
            this.Controls.Add(this.txtquestion);
            this.DoubleBuffered = true;
            this.Name = "frmpicquestion";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.frmpicquestion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picquestion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblquestionid;
        private System.Windows.Forms.Button btnupload;
        private System.Windows.Forms.TextBox txtquestion;
        private System.Windows.Forms.PictureBox picquestion;
        private System.Windows.Forms.RadioButton rdbtrue;
        private System.Windows.Forms.RadioButton rdbfalse;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.TextBox txtsessionid;
        private System.Windows.Forms.TextBox txtstudid;
    }
}