﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teach_Boards
{
    public partial class frmmenu : Form
    {
        public frmmenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmteachmenu fm = new frmteachmenu();
            fm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmstudmenu fm = new frmstudmenu();
            fm.ShowDialog();
        }
    }
}
