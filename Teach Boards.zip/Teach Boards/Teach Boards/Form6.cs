﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmpicquestion : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        DataSet ds2;
        String sql;
        OleDbDataAdapter da, da2;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;
        int StudentID;
        int SessionID;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmpicquestion()
        {
            InitializeComponent();
        }

        private void frmpicquestion_Load(object sender, EventArgs e)
        {
            picquestion.Hide();
            rdbtrue.Hide();
            rdbfalse.Hide();

            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();


                sql = "SELECT ImageQuest.ImageQuestID, ImageQuest.Question, ImageQuest.Imagename, ImageQuest.Correct FROM ImageQuest; ";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "ImageQuest");
                numRows = ds.Tables["ImageQuest"].Rows.Count;
                populateImageQuest();

                ds2 = new DataSet();

                sql = "SELECT * FROM StudentImageAns";
                da2 = new OleDbDataAdapter(sql, con);
                da2.Fill(ds2, "StudentImageAns");
             //   numRows = ds2.Tables["StudentImageAns"].Rows.Count;
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void populateImageQuest()
        {
            dRow = ds.Tables["ImageQuest"].Rows[currentRow];
            String ImageQuestID = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = ImageQuestID;
            trackID = ImageQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;

            String imagename = dRow.ItemArray.GetValue(2).ToString();
            picquestion.Image = Image.FromFile(imagename);
        }

        private void btnupload_Click(object sender, EventArgs e)
        {
            if (rdbtrue.Checked == true) { answerpicture(lblquestionid.Text, rdbtrue.Text); }
            if (rdbfalse.Checked == true) { answerpicture(lblquestionid.Text, rdbfalse.Text); }

            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateImageQuest();
            }
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            StudentID = Int32.Parse(txtstudid.Text);
            SessionID = Int32.Parse(txtsessionid.Text);

            txtsessionid.Hide();
            txtstudid.Hide();
            btnlogin.Hide();

            picquestion.Show();
            rdbtrue.Show();
            rdbfalse.Show();
        }

        private void answerpicture(string QID,string answ)
        {
            try
            {
                DataRow dRow = ds2.Tables["StudentImageAns"].NewRow();
                dRow[1] = StudentID;
                dRow[2] = QID;
                dRow[3] = answ;
                dRow[4] = SessionID;
                ds2.Tables["StudentImageAns"].Rows.Add(dRow);
              //  numRows = numRows + 1;
              //  currentRow = numRows - 1;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da2);
                cb.DataAdapter.Update(ds2.Tables["StudentImageAns"]);

                MessageBox.Show("Question Uploaded");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
