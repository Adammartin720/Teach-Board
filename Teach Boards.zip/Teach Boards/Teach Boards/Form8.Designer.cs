﻿namespace Teach_Boards
{
    partial class frmviewstudanswermc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.dgvanswers = new System.Windows.Forms.DataGridView();
            this.txtsession = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnload = new System.Windows.Forms.Button();
            this.btnreview1 = new System.Windows.Forms.Button();
            this.btnreview2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvanswers)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Multiple Choice";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(10, 268);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(92, 40);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // dgvanswers
            // 
            this.dgvanswers.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvanswers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvanswers.Location = new System.Drawing.Point(116, 87);
            this.dgvanswers.Name = "dgvanswers";
            this.dgvanswers.Size = new System.Drawing.Size(390, 221);
            this.dgvanswers.TabIndex = 6;
            // 
            // txtsession
            // 
            this.txtsession.Location = new System.Drawing.Point(116, 55);
            this.txtsession.Name = "txtsession";
            this.txtsession.Size = new System.Drawing.Size(180, 20);
            this.txtsession.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 49);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Session";
            // 
            // btnload
            // 
            this.btnload.BackColor = System.Drawing.Color.White;
            this.btnload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.Location = new System.Drawing.Point(302, 49);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(92, 32);
            this.btnload.TabIndex = 9;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = false;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnreview1
            // 
            this.btnreview1.BackColor = System.Drawing.Color.White;
            this.btnreview1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreview1.Location = new System.Drawing.Point(12, 137);
            this.btnreview1.Name = "btnreview1";
            this.btnreview1.Size = new System.Drawing.Size(92, 40);
            this.btnreview1.TabIndex = 10;
            this.btnreview1.Text = "Student View";
            this.btnreview1.UseVisualStyleBackColor = false;
            this.btnreview1.Click += new System.EventHandler(this.btnreview1_Click);
            // 
            // btnreview2
            // 
            this.btnreview2.BackColor = System.Drawing.Color.White;
            this.btnreview2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreview2.Location = new System.Drawing.Point(12, 183);
            this.btnreview2.Name = "btnreview2";
            this.btnreview2.Size = new System.Drawing.Size(92, 40);
            this.btnreview2.TabIndex = 11;
            this.btnreview2.Text = "Percent View";
            this.btnreview2.UseVisualStyleBackColor = false;
            this.btnreview2.Click += new System.EventHandler(this.btnreview2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(192, 13);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "- Question View";
            // 
            // frmviewstudanswermc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(517, 315);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnreview2);
            this.Controls.Add(this.btnreview1);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsession);
            this.Controls.Add(this.dgvanswers);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label1);
            this.Name = "frmviewstudanswermc";
            this.Text = "MC Question View";
            this.Load += new System.EventHandler(this.frmviewstudanswermc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvanswers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView dgvanswers;
        private System.Windows.Forms.TextBox txtsession;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Button btnreview1;
        private System.Windows.Forms.Button btnreview2;
        private System.Windows.Forms.Label label3;
    }
}