﻿namespace Teach_Boards
{
    partial class frmstudentimageview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreview2 = new System.Windows.Forms.Button();
            this.btnreview1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnload = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsession = new System.Windows.Forms.TextBox();
            this.dgvanswers = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvanswers)).BeginInit();
            this.SuspendLayout();
            // 
            // btnreview2
            // 
            this.btnreview2.BackColor = System.Drawing.Color.White;
            this.btnreview2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreview2.Location = new System.Drawing.Point(12, 183);
            this.btnreview2.Name = "btnreview2";
            this.btnreview2.Size = new System.Drawing.Size(92, 40);
            this.btnreview2.TabIndex = 28;
            this.btnreview2.Text = "Percent View";
            this.btnreview2.UseVisualStyleBackColor = false;
            this.btnreview2.Click += new System.EventHandler(this.btnreview2_Click);
            // 
            // btnreview1
            // 
            this.btnreview1.BackColor = System.Drawing.Color.White;
            this.btnreview1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreview1.Location = new System.Drawing.Point(12, 137);
            this.btnreview1.Name = "btnreview1";
            this.btnreview1.Size = new System.Drawing.Size(92, 40);
            this.btnreview1.TabIndex = 27;
            this.btnreview1.Text = "Question View";
            this.btnreview1.UseVisualStyleBackColor = false;
            this.btnreview1.Click += new System.EventHandler(this.btnreview1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(138, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 18);
            this.label3.TabIndex = 26;
            this.label3.Text = "- Student View";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 25);
            this.label1.TabIndex = 25;
            this.label1.Text = "Image T/F";
            // 
            // btnload
            // 
            this.btnload.BackColor = System.Drawing.Color.White;
            this.btnload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.Location = new System.Drawing.Point(302, 49);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(92, 32);
            this.btnload.TabIndex = 24;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = false;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 49);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 25);
            this.label2.TabIndex = 23;
            this.label2.Text = "Session";
            // 
            // txtsession
            // 
            this.txtsession.Location = new System.Drawing.Point(116, 55);
            this.txtsession.Name = "txtsession";
            this.txtsession.Size = new System.Drawing.Size(180, 20);
            this.txtsession.TabIndex = 22;
            // 
            // dgvanswers
            // 
            this.dgvanswers.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvanswers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvanswers.Location = new System.Drawing.Point(116, 87);
            this.dgvanswers.Name = "dgvanswers";
            this.dgvanswers.Size = new System.Drawing.Size(387, 221);
            this.dgvanswers.TabIndex = 21;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(12, 268);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(92, 40);
            this.btnClose.TabIndex = 20;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // frmstudentimageview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(518, 316);
            this.Controls.Add(this.btnreview2);
            this.Controls.Add(this.btnreview1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsession);
            this.Controls.Add(this.dgvanswers);
            this.Controls.Add(this.btnClose);
            this.Name = "frmstudentimageview";
            this.Text = "Form16";
            ((System.ComponentModel.ISupportInitialize)(this.dgvanswers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnreview2;
        private System.Windows.Forms.Button btnreview1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsession;
        private System.Windows.Forms.DataGridView dgvanswers;
        private System.Windows.Forms.Button btnClose;
    }
}