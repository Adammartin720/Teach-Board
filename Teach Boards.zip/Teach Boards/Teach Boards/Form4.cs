﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmesasayques : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        DataSet ds2;
        String sql;
        OleDbDataAdapter da, da2;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;
        int StudentID;
        int SessionID;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmesasayques()
        {
            InitializeComponent();
        }

        private void frmesasayques_Load(object sender, EventArgs e)
        {
            txtans.Hide();

            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();


                sql = "SELECT EssayQuest.EssayQuestID, EssayQuest.Question, EssayQuest.Correct FROM EssayQuest GROUP BY EssayQuest.EssayQuestID, EssayQuest.Question, EssayQuest.Correct; ";

                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "EssayQuest");
                numRows = ds.Tables["EssayQuest"].Rows.Count;
                populateEssayQuestions();


                ds2 = new DataSet();

                sql = "SELECT * FROM StudentEssayAns";
                da2 = new OleDbDataAdapter(sql, con);
                da2.Fill(ds2, "StudentEssayAns");


            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void answeressay(string QID, string answ)
        {
            try
            {
                DataRow dRow = ds2.Tables["StudentEssayAns"].NewRow();
                dRow[1] = StudentID;
                dRow[2] = QID;
                dRow[3] = answ;
                dRow[4] = SessionID;
                ds2.Tables["StudentEssayAns"].Rows.Add(dRow);
                //  numRows = numRows + 1;
                //  currentRow = numRows - 1;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da2);
                cb.DataAdapter.Update(ds2.Tables["StudentEssayAns"]);

                MessageBox.Show("Question Uploaded");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void btnupload_Click(object sender, EventArgs e)
        {
            answeressay(lblquestionid.Text, txtans.Text);

            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateEssayQuestions();
            }
            txtans.Text = String.Empty;
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            StudentID = Int32.Parse(txtstudid.Text);
            SessionID = Int32.Parse(txtsessionid.Text);

            txtsessionid.Hide();
            txtstudid.Hide();
            btnlogin.Hide();
            txtans.Show();
            
        }

        private void populateEssayQuestions()
        {
            dRow = ds.Tables["EssayQuest"].Rows[currentRow];
            String EssayQuestID = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = EssayQuestID;
            trackID = EssayQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;
        }
    }
}
