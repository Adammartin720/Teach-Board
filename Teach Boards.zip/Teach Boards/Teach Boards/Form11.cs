﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects


namespace Teach_Boards
{
    public partial class frmstudentview : Form
    {
        //variable to store customerID from view Customers form
        string SessionID;

        //database variables and objects
        String connectionString;
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader dr;

        public frmstudentview()
        {
            InitializeComponent();
        }

        
        private void btnload_Click(object sender, EventArgs e)
        {
            //Get the customer ID
            SessionID = txtsession.Text;// ((StudentAnswers)this.Owner).trackID;

            //access the database for the records
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                //Open the connection to the database
                con.Open();
                //Create a new command object
                cmd = new OleDbCommand();
                //Set the SQL command text
                                cmd.CommandText = "TRANSFORM First(IIf([CORRECT]=[ANSWER],1,0)) AS Score " +
                "SELECT Student.Studentname " +
                "FROM Student INNER JOIN(Questions INNER JOIN StudentAnswers ON Questions.QuestionID = StudentAnswers.QuestionID) ON Student.StudentID = StudentAnswers.StudID " +
                "WHERE (((StudentAnswers.SessionID)= " + SessionID + " )) " +
                "GROUP BY Student.Studentname " +
                "PIVOT Questions.QuestionID; ";

                //Link the command to the connection so the correct DB is used
                cmd.Connection = con;
                //Add the primary key parameter
                cmd.Parameters.AddWithValue("SessionID", SessionID);
                //Run the command and store resulting table in the datareader
                dr = cmd.ExecuteReader();



                if (dr.HasRows)
                {
                    int DRFC = dr.FieldCount;
                    DataTable dt = new DataTable();
                    for (int i = 0; i <= DRFC - 1; i++)
                    {
                        dt.Columns.Add(dr.GetName(i));
                    }

                    while (dr.Read())
                    {
                        DataRow workRow = dt.NewRow();

                        for (int i = 0; i <= DRFC - 1; i++)
                        {
                            workRow[i] = dr[i].ToString();
                            String s = dr.GetName(i);
                        }
                        dt.Rows.Add(workRow);

                    }
                    dgvanswers.DataSource = dt;
                }
                else
                {

                }
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnreview2_Click(object sender, EventArgs e)
        {
            frmpercentview fm = new frmpercentview();
            fm.ShowDialog();
        }

        private void btnreview1_Click(object sender, EventArgs e)
        {

            frmviewstudanswermc fm = new frmviewstudanswermc();
            fm.ShowDialog();
        }
    }
}
