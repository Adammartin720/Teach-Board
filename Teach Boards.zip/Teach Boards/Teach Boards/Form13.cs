﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmteachboard2 : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        String sql;
        OleDbDataAdapter da;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmteachboard2()
        {
            InitializeComponent();
        }

        private void frmteachboard2_Load(object sender, EventArgs e)
        {
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();
                sql = "SELECT * FROM ImageQuest";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "ImageQuest");
                numRows = ds.Tables["ImageQuest"].Rows.Count;
                populateImageQuest();
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void populateImageQuest()
        {
            dRow = ds.Tables["ImageQuest"].Rows[currentRow];
            String ImageQuestID = dRow.ItemArray.GetValue(0).ToString();
            lblquestionid.Text = ImageQuestID;
            trackID = ImageQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquestion.Text = question;

            String imagename = dRow.ItemArray.GetValue(2).ToString();
            picquestion.Image = Image.FromFile(imagename);
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateImageQuest();
            }
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            if (currentRow > 0)
            {
                currentRow--;
                populateImageQuest();
            }
        }

        private void btnstudans_Click(object sender, EventArgs e)
        {
            frmviewstudanswerim fm = new frmviewstudanswerim();
            fm.ShowDialog();
        }
    }
}
