﻿namespace Teach_Boards
{
    partial class frmstudentques
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmstudentques));
            this.rbanswer1 = new System.Windows.Forms.RadioButton();
            this.rbanswer3 = new System.Windows.Forms.RadioButton();
            this.rbanswer4 = new System.Windows.Forms.RadioButton();
            this.rbanswer2 = new System.Windows.Forms.RadioButton();
            this.lblvideo = new System.Windows.Forms.Label();
            this.txtquestion = new System.Windows.Forms.TextBox();
            this.btnmedia = new System.Windows.Forms.Button();
            this.btnupload = new System.Windows.Forms.Button();
            this.lblquestionid = new System.Windows.Forms.Label();
            this.lblanswera = new System.Windows.Forms.Label();
            this.lblanswerb = new System.Windows.Forms.Label();
            this.lblanswerc = new System.Windows.Forms.Label();
            this.lblanswerd = new System.Windows.Forms.Label();
            this.txtstudid = new System.Windows.Forms.TextBox();
            this.txtsessionid = new System.Windows.Forms.TextBox();
            this.btnlogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rbanswer1
            // 
            this.rbanswer1.AutoSize = true;
            this.rbanswer1.Location = new System.Drawing.Point(34, 207);
            this.rbanswer1.Name = "rbanswer1";
            this.rbanswer1.Size = new System.Drawing.Size(32, 17);
            this.rbanswer1.TabIndex = 0;
            this.rbanswer1.TabStop = true;
            this.rbanswer1.Text = "A";
            this.rbanswer1.UseVisualStyleBackColor = true;
            // 
            // rbanswer3
            // 
            this.rbanswer3.AutoSize = true;
            this.rbanswer3.Location = new System.Drawing.Point(34, 270);
            this.rbanswer3.Name = "rbanswer3";
            this.rbanswer3.Size = new System.Drawing.Size(32, 17);
            this.rbanswer3.TabIndex = 1;
            this.rbanswer3.TabStop = true;
            this.rbanswer3.Text = "C";
            this.rbanswer3.UseVisualStyleBackColor = true;
            // 
            // rbanswer4
            // 
            this.rbanswer4.AutoSize = true;
            this.rbanswer4.Location = new System.Drawing.Point(125, 270);
            this.rbanswer4.Name = "rbanswer4";
            this.rbanswer4.Size = new System.Drawing.Size(33, 17);
            this.rbanswer4.TabIndex = 2;
            this.rbanswer4.TabStop = true;
            this.rbanswer4.Text = "D";
            this.rbanswer4.UseVisualStyleBackColor = true;
            // 
            // rbanswer2
            // 
            this.rbanswer2.AutoSize = true;
            this.rbanswer2.Location = new System.Drawing.Point(125, 207);
            this.rbanswer2.Name = "rbanswer2";
            this.rbanswer2.Size = new System.Drawing.Size(32, 17);
            this.rbanswer2.TabIndex = 3;
            this.rbanswer2.TabStop = true;
            this.rbanswer2.Text = "B";
            this.rbanswer2.UseVisualStyleBackColor = true;
            // 
            // lblvideo
            // 
            this.lblvideo.AutoSize = true;
            this.lblvideo.Location = new System.Drawing.Point(160, 313);
            this.lblvideo.Name = "lblvideo";
            this.lblvideo.Size = new System.Drawing.Size(24, 13);
            this.lblvideo.TabIndex = 10;
            this.lblvideo.Text = "test";
            this.lblvideo.Visible = false;
            // 
            // txtquestion
            // 
            this.txtquestion.Location = new System.Drawing.Point(46, 101);
            this.txtquestion.Name = "txtquestion";
            this.txtquestion.ReadOnly = true;
            this.txtquestion.Size = new System.Drawing.Size(147, 20);
            this.txtquestion.TabIndex = 9;
            // 
            // btnmedia
            // 
            this.btnmedia.BackColor = System.Drawing.Color.White;
            this.btnmedia.Location = new System.Drawing.Point(138, 329);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(67, 34);
            this.btnmedia.TabIndex = 8;
            this.btnmedia.Text = "Media";
            this.btnmedia.UseVisualStyleBackColor = false;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // btnupload
            // 
            this.btnupload.BackColor = System.Drawing.Color.White;
            this.btnupload.Location = new System.Drawing.Point(28, 329);
            this.btnupload.Name = "btnupload";
            this.btnupload.Size = new System.Drawing.Size(67, 34);
            this.btnupload.TabIndex = 11;
            this.btnupload.Text = "Upload";
            this.btnupload.UseVisualStyleBackColor = false;
            this.btnupload.Click += new System.EventHandler(this.btnupload_Click);
            // 
            // lblquestionid
            // 
            this.lblquestionid.AutoSize = true;
            this.lblquestionid.Location = new System.Drawing.Point(102, 85);
            this.lblquestionid.Name = "lblquestionid";
            this.lblquestionid.Size = new System.Drawing.Size(35, 13);
            this.lblquestionid.TabIndex = 12;
            this.lblquestionid.Text = "label1";
            // 
            // lblanswera
            // 
            this.lblanswera.AutoSize = true;
            this.lblanswera.Location = new System.Drawing.Point(52, 191);
            this.lblanswera.Name = "lblanswera";
            this.lblanswera.Size = new System.Drawing.Size(57, 13);
            this.lblanswera.TabIndex = 13;
            this.lblanswera.Text = "lblanswera";
            // 
            // lblanswerb
            // 
            this.lblanswerb.AutoSize = true;
            this.lblanswerb.Location = new System.Drawing.Point(144, 191);
            this.lblanswerb.Name = "lblanswerb";
            this.lblanswerb.Size = new System.Drawing.Size(35, 13);
            this.lblanswerb.TabIndex = 14;
            this.lblanswerb.Text = "label2";
            // 
            // lblanswerc
            // 
            this.lblanswerc.AutoSize = true;
            this.lblanswerc.Location = new System.Drawing.Point(52, 251);
            this.lblanswerc.Name = "lblanswerc";
            this.lblanswerc.Size = new System.Drawing.Size(35, 13);
            this.lblanswerc.TabIndex = 15;
            this.lblanswerc.Text = "label3";
            // 
            // lblanswerd
            // 
            this.lblanswerd.AutoSize = true;
            this.lblanswerd.Location = new System.Drawing.Point(144, 250);
            this.lblanswerd.Name = "lblanswerd";
            this.lblanswerd.Size = new System.Drawing.Size(35, 13);
            this.lblanswerd.TabIndex = 16;
            this.lblanswerd.Text = "label4";
            // 
            // txtstudid
            // 
            this.txtstudid.Location = new System.Drawing.Point(46, 127);
            this.txtstudid.Name = "txtstudid";
            this.txtstudid.Size = new System.Drawing.Size(57, 20);
            this.txtstudid.TabIndex = 17;
            // 
            // txtsessionid
            // 
            this.txtsessionid.Location = new System.Drawing.Point(136, 127);
            this.txtsessionid.Name = "txtsessionid";
            this.txtsessionid.Size = new System.Drawing.Size(57, 20);
            this.txtsessionid.TabIndex = 18;
            // 
            // btnlogin
            // 
            this.btnlogin.BackColor = System.Drawing.Color.White;
            this.btnlogin.Location = new System.Drawing.Point(82, 153);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnlogin.Size = new System.Drawing.Size(75, 23);
            this.btnlogin.TabIndex = 19;
            this.btnlogin.Text = "Login";
            this.btnlogin.UseVisualStyleBackColor = false;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // frmstudentques
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(230, 457);
            this.Controls.Add(this.btnlogin);
            this.Controls.Add(this.txtsessionid);
            this.Controls.Add(this.txtstudid);
            this.Controls.Add(this.lblanswerd);
            this.Controls.Add(this.lblanswerc);
            this.Controls.Add(this.lblanswerb);
            this.Controls.Add(this.lblanswera);
            this.Controls.Add(this.lblquestionid);
            this.Controls.Add(this.btnupload);
            this.Controls.Add(this.lblvideo);
            this.Controls.Add(this.txtquestion);
            this.Controls.Add(this.btnmedia);
            this.Controls.Add(this.rbanswer2);
            this.Controls.Add(this.rbanswer4);
            this.Controls.Add(this.rbanswer3);
            this.Controls.Add(this.rbanswer1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmstudentques";
            this.Text = "MultQuestion";
            this.Load += new System.EventHandler(this.frmstudentques_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbanswer1;
        private System.Windows.Forms.RadioButton rbanswer3;
        private System.Windows.Forms.RadioButton rbanswer4;
        private System.Windows.Forms.RadioButton rbanswer2;
        private System.Windows.Forms.Label lblvideo;
        private System.Windows.Forms.TextBox txtquestion;
        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnupload;
        private System.Windows.Forms.Label lblquestionid;
        private System.Windows.Forms.Label lblanswera;
        private System.Windows.Forms.Label lblanswerb;
        private System.Windows.Forms.Label lblanswerc;
        private System.Windows.Forms.Label lblanswerd;
        private System.Windows.Forms.TextBox txtstudid;
        private System.Windows.Forms.TextBox txtsessionid;
        private System.Windows.Forms.Button btnlogin;
    }
}