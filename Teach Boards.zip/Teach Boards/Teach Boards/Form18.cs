﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmessaycreate : Form
    {
        String connectionString;
        OleDbConnection con;
        DataSet ds;
        String sql;
        OleDbDataAdapter da;
        DataRow dRow;
        int numRows = 0;
        int currentRow = 0;

        //Variable to hold questionID so frmteach can access it
        public string trackID;

        public frmessaycreate()
        {
            InitializeComponent();
        }

        private void Form18_Load(object sender, EventArgs e)
        {
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                con.Open();
                ds = new DataSet();


                sql = "SELECT * FROM EssayQuest";
                da = new OleDbDataAdapter(sql, con);
                da.Fill(ds, "EssayQuest");
                numRows = ds.Tables["EssayQuest"].Rows.Count;
                populateEssayQuestcreate();
                
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void populateEssayQuestcreate()
        {
            dRow = ds.Tables["EssayQuest"].Rows[currentRow];
            String EssayQuestID = dRow.ItemArray.GetValue(0).ToString();
            txtID.Text = EssayQuestID;
            trackID = EssayQuestID;

            String question = dRow.ItemArray.GetValue(1).ToString();
            txtquesname.Text = question;

            String correct = dRow.ItemArray.GetValue(2).ToString();
            txtanswer.Text = correct;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dRow = ds.Tables["EssayQuest"].NewRow();
                dRow[1] = txtquesname.Text;
                dRow[2] = txtanswer.Text;
                
                ds.Tables["EssayQuest"].Rows.Add(dRow);
                numRows = numRows + 1;
                currentRow = numRows - 1;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["EssayQuest"]);
                btnSave.Enabled = false;
                btnNew.Enabled = true;
                MessageBox.Show("Record saved");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentRow < numRows - 1)
            {
                currentRow++;
                populateEssayQuestcreate();
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentRow > 0)
            {
                currentRow--;
                populateEssayQuestcreate();
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentRow = 0;
            populateEssayQuestcreate();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentRow = numRows - 1;
            populateEssayQuestcreate();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtquesname.Clear();
            txtID.Clear();
            txtanswer.Clear();

            btnSave.Enabled = true;
            btnNew.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnNext.Enabled = false;
            btnPrevious.Enabled = false;
            btnFirst.Enabled = false;
            btnLast.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dRow2 = ds.Tables["EssayQuest"].Rows[currentRow];
                dRow2[1] = txtquesname.Text;
                dRow2[2] = txtanswer.Text;
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["EssayQuest"]);

                MessageBox.Show("EssayQuest updated");
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Tables["EssayQuest"].Rows[currentRow].Delete();
                OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
                cb.DataAdapter.Update(ds.Tables["EssayQuest"]);
                numRows = ds.Tables["EssayQuest"].Rows.Count;
                MessageBox.Show("EssayQuest record deleted");
                currentRow = currentRow - 1;
                populateEssayQuestcreate();
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
