﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb; //Needed for Access database objects

namespace Teach_Boards
{
    public partial class frmessayview : Form
    {
        //variable to store customerID from view Customers form
        string SessionID;

        //database variables and objects
        String connectionString;
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader dr;
        public frmessayview()
        {
            InitializeComponent();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            //Get the session ID
            SessionID = txtsession.Text;// ((StudentAnswers)this.Owner).trackID;

            //access the database for the records
            connectionString = staticConnectionString.connectionString;
            con = new OleDbConnection(connectionString);
            try
            {
                //Open the connection to the database
                con.Open();
                //Create a new command object
                cmd = new OleDbCommand();
                //Set the SQL command text
                cmd.CommandText = "SELECT EssayQuest.Question, StudentEssayAns.Answer, Student.Studentname " +
                                   "FROM(StudentEssayAns INNER JOIN EssayQuest ON StudentEssayAns.EssayQuestD = EssayQuest.EssayQuestID) INNER JOIN Student ON StudentEssayAns.StudID = Student.StudentID " +
                                   "WHERE(((StudentEssayAns.SessionID)= " + SessionID + " )) " +
                                   "GROUP BY EssayQuest.Question, StudentEssayAns.Answer, Student.Studentname;";               

                //Link the command to the connection so the correct DB is used
                cmd.Connection = con;
                //Add the primary key parameter
                cmd.Parameters.AddWithValue("SessionID", SessionID);
                //Run the command and store resulting table in the datareader
                dr = cmd.ExecuteReader();



                if (dr.HasRows)
                {
                    int DRFC = dr.FieldCount;
                    DataTable dt = new DataTable();
                    for (int i = 0; i <= DRFC - 1; i++)
                    {
                        dt.Columns.Add(dr.GetName(i));
                    }

                    while (dr.Read())
                    {
                        DataRow workRow = dt.NewRow();

                        for (int i = 0; i <= DRFC - 1; i++)
                        {
                            workRow[i] = dr[i].ToString();
                            String s = dr.GetName(i);
                        }
                        dt.Rows.Add(workRow);

                    }
                    dgvanswers.DataSource = dt;
                }
                else
                {

                }
            }
            catch (Exception err)
            {
                MessageBox.Show("A database error has occurred: " + Environment.NewLine + err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
